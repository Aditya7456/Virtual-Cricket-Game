#include"player.h" // <string>
Player:: Player(){ // @suppress("Class members should be properly initialized")
	runsScored=0;
    ballsPlayed=0;
    ballsBowled=0;
    runsGiven=0;
    wicketsTaken=0;
}
