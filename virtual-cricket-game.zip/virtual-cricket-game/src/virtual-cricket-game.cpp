#include "game.h"
using namespace std;

int main() {
   Game game;
   game.welcome();
   cout<<"\nPress Enter to Continue....\n\n";
   getchar();
   game.showAllPlayers();
   cout<<"\nPress Enter to Continue....\n\n";
   getchar();
   game.selectPlayers();
   game.showTeamPlayers();
   cout<<"\nPress Enter to Continue....\n\n";
   getchar();
   game.Lets_Toss();
   game.startFirstInnings();
   cout<<"\nPress Enter to Continue....\n\n";
   getchar();
   game.startSecondInnings();
   cout<<"\nPress Enter to Continue....\n\n";
   getchar();
   game.showFinalScorecard();
   getch();
   return 0;

}
