#include<iostream>
#include<conio.h>
#include<cstdlib>
#include<stdio.h>
#include<ctime>
#include<limits>
#include"team.h" // <string> <vector> "player.h"
class Game {
public:
	Game();
	int playersPerTeam;
	int maxBalls;
	int totalPlayers;
	std::string Players[11];
   Team teamA,teamB;
   Team *battingTeam;
   Team *bowlingTeam;
   Player *batsman, *bowler;
   bool isFirstInnings;
   void welcome();
   void showAllPlayers();
   int takeIntegerInput();
   void selectPlayers();
   bool validateSelectedPlayer(int);
   void showTeamPlayers();
   void Lets_Toss();
   void tossChoice(Team);
   void startFirstInnings();
   void initializePlayers();
   void playInnings();
   void bat();
   bool validateInningsScore();
   void showGameScorecard();
   void startSecondInnings();
   void showFinalScorecard();
};
