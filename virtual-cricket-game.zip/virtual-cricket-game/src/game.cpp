#include"game.h"
using namespace std;
Game :: Game() { // @suppress("Class members should be properly initialized")
	playersPerTeam=4;
	maxBalls=6;
	totalPlayers=11;
	Players[0]="Virat";
	Players[1]="Varun";
	Players[2]="Rohit";
	Players[3]="Kalua";
	Players[4]="Mula";
	Players[5]="Kallu";
	Players[6]="Nandu";
	Players[7]="Mannu";
	Players[8]="Vijay";
    Players[9]="Murali";
    Players[10]="Vardhan";
	isFirstInnings=0;
	teamA.name="Team-A";
	teamB.name="Team-B";
}
void Game:: welcome(){

	cout<<"			 ---------------------------------------------------"<<endl;
	cout<<"			|======================CRIC-IN======================|"<<endl;
	cout<<"			|                                                   |"<<endl;
	cout<<"			|        Welcome to the Virtual Cricket Game        |"<<endl;
	cout<<"			|                                                   |"<<endl;
	cout<<"			|___________________________________________________|"<<endl<<endl;

	cout<<" -----------------------------------------------------------------------------------------"<<endl;
	cout<<"|====================================INSTRUCTIONS=========================================|"<<endl;
	cout<<" ----------------------------------------------------------------------------------------- "<<endl;
	cout<<"|  1.Create 2 Teams (Team-A and Team-B with players each) from the given set of 11 Player |"<<endl;
	cout<<"|  2.Lead the toss and decide the choice of play.                                         |"<<endl;
	cout<<"|  3.Each Inning will be of six ball.                                                     |"<<endl;
    cout<<"|  4.Scoring 0 will leads your batsman declared out.                                      |"<<endl;
    cout<<"|  5.1st Selected Player from Bowling Team will bowl all the six balls.                   |"<<endl;
    cout<<"|_________________________________________________________________________________________|"<<endl;
}
void Game:: showAllPlayers(){

	cout<<" -------------------------------"<<endl;
	cout<<"|=========Pool of Players======|"<<endl;
	cout<<" -------------------------------"<<endl;

	for(int i=0;i<11;i++){
        cout<<"\t["<< i << "] "<<Players[i]<<endl;
	}
}
int Game :: takeIntegerInput(){

	int n;
   while(!(cin>>n)){
	   cin.clear();
	   cin.ignore(numeric_limits<streamsize>::max(),'\n');
	   cout<<"Invalid input! Please try again with valid input: ";
   }
   return n;

}
void Game :: selectPlayers(){

	    cout<<" ---------------------------------------"<<endl;
		cout<<"|=========Create Team-A and Team-B======|"<<endl;
		cout<<" ---------------------------------------"<<endl<<endl;
	   for(int i=0;i<playersPerTeam;i++){

		   // Add players to Team-A
		   teamAselection:
		   cout<<"Select Player "<<i+1<<" of Team-A - ";

		   int playerIndexTeamA=takeIntegerInput();

		   if(playerIndexTeamA<0 || playerIndexTeamA>10){

			   cout<<endl<<"Please Select from the given players"<<endl;
			   goto teamAselection;
		   }

		   else if (!validateSelectedPlayer(playerIndexTeamA)){
                   cout<<endl<<"Player has already been selected.Please select other player"<<endl;
                   goto teamAselection;
		   }

		   else {

			           Player teamAPlayer;
			  		   teamAPlayer.id=playerIndexTeamA;
			  		   teamAPlayer.name=Players[playerIndexTeamA];
			  		   teamA.players.push_back(teamAPlayer);
		   }

		   // Add players to Team-B
		   teamBselection:
		   cout<<"Select Player "<<i+1<<" of Team-B - ";

		   int playerIndexTeamB=takeIntegerInput();

		   if(playerIndexTeamB<0 || playerIndexTeamB>10){

		   			   cout<<endl<<"Please Select from the given players"<<endl;
		   			   goto teamBselection;
		   	 }
		   else if (!validateSelectedPlayer(playerIndexTeamB)){

		                  cout<<endl<<"Player has already been selected.Please select other player"<<endl;
		                  goto teamBselection;
		   		   }
		    else {
		   			           Player teamBPlayer;
		   			  		   teamBPlayer.id=playerIndexTeamB;
		   			  		   teamBPlayer.name=Players[playerIndexTeamB];
		   			  		   teamB.players.push_back(teamBPlayer);
		   	 }

	   }
}
 bool Game:: validateSelectedPlayer(int x){
     int n;
     vector<Player>player;

     player=teamA.players;
     n=player.size();
     for(int i=0;i<n;i++){
    	 if(player[i].id==x){
    		 return false;
    	 }
     }

     player=teamB.players;
     n=player.size();
     for(int i=0;i<n;i++){
    	 if(player[i].id==x){
    		 return false;
    	 }
     }
     return true;
 }
void Game:: showTeamPlayers(){

	vector<Player>teamAPlayers=teamA.players;
	vector<Player>teamBPlayers=teamB.players;
	cout<<endl<<endl;
    cout<<"--------------------------\t\t--------------------------"<<endl;
    cout<<"|=========Team-A=========|\t\t|=========Team-B=========|"<<endl;
    cout<<"--------------------------\t\t--------------------------"<<endl;
for(int i=0;i<4;i++){

	cout<<"|\t["<<i<<"] "<<teamAPlayers[i].name
			<<"\t |\t\t|\t["<<i<<"] "<<teamBPlayers[i].name<<"\t |"<<endl;

  }
cout<<"--------------------------\t\t--------------------------"<<endl;

}
void Game:: Lets_Toss(){

    int randomValue;
    srand(time(NULL));

            cout<<" ---------------------------------------"<<endl;
    		cout<<"|================Let's Toss=============|"<<endl;
    		cout<<" ---------------------------------------"<<endl<<endl;
    		randomValue=((rand())%2);
    		cout<<"Tossing Coin..."<<endl;

    	if(randomValue ==0){
    		cout<<"Team-A have won the Toss\n\n";
    		tossChoice(teamA);
    	}

    	else {
    		cout<<"Team-B have won the Toss\n\n";
    		tossChoice(teamB);

    	}
}
void Game:: tossChoice(Team tossWinnerTeam){

      cout<<"Enter 1 to Bat and 2 to Ball first"<<endl;
      cout<<"1.Bat\n2.Ball\n";
      choice:
      int n = takeIntegerInput();

      if(n==1){
    	  cout<<endl<<tossWinnerTeam.name<<" have won the toss and elected to bat first."<<endl<<endl;
    	  if(tossWinnerTeam.name.compare("Team-A")==0){
    		  battingTeam=&teamA;
    		  bowlingTeam=&teamB;
    	  }
    	  else {
    		  battingTeam=&teamB;
    		  bowlingTeam=&teamA;
    	  }
      }
      else if(n==2){
    	  cout<<endl<<tossWinnerTeam.name<<" have won the toss and elected to ball first."<<endl<<endl;
           if(tossWinnerTeam.name.compare("Team-B")==0){
        	   battingTeam=&teamA;
        	   bowlingTeam=&teamB;
           }
           else {
        	   battingTeam=&teamB;
        	   bowlingTeam=&teamA;
           }
      }
      else {
    	  cout<<"Invalid Input Please Try Again."<<endl;
    	  goto choice;
      }
}
void Game::startFirstInnings(){

    cout<<"\t\t.........|||FIRST INNINGS STARTS|||.........\t\t"<<endl<<endl;
    isFirstInnings=true;
    initializePlayers();
    playInnings();

}
void Game::initializePlayers(){

	batsman=&battingTeam->players[0];
	bowler=&bowlingTeam->players[0];
	getchar();
	cout<<battingTeam->name<<" - "<<batsman->name<<" is batting "<<endl;
	cout<<bowlingTeam->name<<" - "<<bowler->name<<" is bowling "<<endl;
}
void Game:: playInnings(){

	for(int i=0;i < maxBalls;i++){
		cout<<"Press Enter to Ball......."<<endl;
		getchar();
		cout<<"Bowling......"<<endl;
		bat();
		if(!validateInningsScore()) {
			break;
		}
	}
}
void Game:: bat(){
   srand(time(NULL));
   int runsScored=rand()%7;
   // Update Batting Team and Batsman Score
     batsman->runsScored =batsman->runsScored + runsScored;
     battingTeam->totalRunsScored=battingTeam->totalRunsScored + runsScored;
     batsman->ballsPlayed=batsman->ballsPlayed+1;
   // Update Bowling Team and Bowler Score
     bowler->ballsBowled=bowler->ballsBowled+1;
     bowlingTeam->totalBallsBowled=bowlingTeam->totalBallsBowled+1;
     bowler->runsGiven=bowler->runsGiven+runsScored;

     if(runsScored==0){
           cout<<endl<<endl<<bowler->name<<" to "<<batsman->name<<" OUT! "<<endl;
           battingTeam->wicketsLost=battingTeam->wicketsLost+1;
           bowler->wicketsTaken=bowler->wicketsTaken+1;
           showGameScorecard();
           int nextPlayerIndex=battingTeam->wicketsLost;
           batsman=&battingTeam->players[nextPlayerIndex];

     }
     else {
    	 cout<<endl<<endl<<bowler->name<<" to "<<batsman->name<<" "<<runsScored<<" runs!"<<endl<<endl;
    	 showGameScorecard();
     }
}
bool Game:: validateInningsScore(){
     if(isFirstInnings){
    	 if(battingTeam->wicketsLost==playersPerTeam || bowlingTeam->totalBallsBowled==maxBalls){
    		 cout<<"\t\t.........|||FIRST INNINGS ENDS|||.........\t\t"<<endl<<endl;
    		 cout<<battingTeam->name<<" "<<battingTeam->totalRunsScored<<" - "<<battingTeam->wicketsLost<<"("<<bowlingTeam->totalBallsBowled<<") "<<endl;
    		 cout<<bowlingTeam->name<<" needs "<<battingTeam->totalRunsScored+1<<" to win the match"<<endl;

    		 return false;
    	 }
     }
     else {
    	 if(battingTeam->wicketsLost==playersPerTeam || bowlingTeam->totalBallsBowled==maxBalls || battingTeam->totalRunsScored>bowlingTeam->totalRunsScored){
    		 if(battingTeam->totalRunsScored>bowlingTeam->totalRunsScored){
    			 cout<< " "<<battingTeam->name<<" Won!"<<endl<<endl;
    			 return false;
    		 }
    		 else if(battingTeam->totalRunsScored==bowlingTeam->totalRunsScored){
    			 cout<<battingTeam->name<<" Draws! the Match"<<endl<<endl;
    			 return false;
    		 }
    		 else if(battingTeam->totalRunsScored<bowlingTeam->totalRunsScored){
    			 cout<<bowlingTeam->name<<" Won! the Match"<<endl<<endl;
    			 return false;
    		 }
    	 }

     }
     return true;
}
void Game:: showGameScorecard(){
	 cout<<"-------------------------------------------------------------------------------------"<<endl;
	 cout<<"\t"<<battingTeam->name<<" "<<battingTeam->totalRunsScored<<" - "<<battingTeam->wicketsLost<<" ("
			 <<bowlingTeam->totalBallsBowled<<") | "<<batsman->name<<" "<<batsman->runsScored<<" ("
			 <<batsman->ballsPlayed<<")\t"<<bowler->name<<" "<<bowler->ballsBowled<<" - "<<bowler->runsGiven
			 <<" - "<<bowler->wicketsTaken<<endl;
	 cout<<"-------------------------------------------------------------------------------------"<<endl;

}
void Game:: startSecondInnings(){

	cout<<"\t\t.........|||SECOND INNINGS STARTS|||.........\t\t"<<endl<<endl;
	Team *temp;
	temp= battingTeam;
    battingTeam=bowlingTeam;
    bowlingTeam=temp;

	  isFirstInnings=false; // @suppress("Invalid arguments")
	  initializePlayers();
	  playInnings();

}

void Game:: showFinalScorecard(){
	cout<<"\t\t.........||| MATCH ENDS |||.........\t\t"<<endl<<endl;
    cout<<battingTeam->name<<" "<<battingTeam->totalRunsScored<<" - "<<battingTeam->wicketsLost<<"("<<bowlingTeam->totalBallsBowled<<")"<<endl;
    cout<<"==========================================="<<endl;
    cout<<"| PLAYER\t"<<" BATTING\tBOWLING   |"<<endl;
    cout<<"-------------------------------------------"<<endl;

    cout<<"| ["<<"0"<<"]"<<battingTeam->players[0].name<<"\t"<<battingTeam->players[0].runsScored
    			<<"("<<battingTeam->players[0].ballsPlayed<<")"<<"\t\t "<<battingTeam->players[0].ballsBowled
    			<<"- "<<battingTeam->players[0].runsGiven<<"-"<<battingTeam->players[0].wicketsTaken<<" |"<<endl;
    cout<<"----------------------------------------"<<endl;
    cout<<"| ["<<"1"<<"]"<<battingTeam->players[1].name<<" \t"<<battingTeam->players[1].runsScored
    				<<"("<<battingTeam->players[1].ballsPlayed<<")"<<"\t\t "<<battingTeam->players[1].ballsBowled
    				<<"- "<<battingTeam->players[1].runsGiven<<"-"<<battingTeam->players[1].wicketsTaken<<" |"<<endl;
    cout<<"----------------------------------------"<<endl;
    cout<<"| ["<<"2"<<"]"<<battingTeam->players[2].name<<" \t"<<battingTeam->players[2].runsScored
    					<<"("<<battingTeam->players[2].ballsPlayed<<")"<<"\t\t "<<battingTeam->players[2].ballsBowled
    					<<"- "<<battingTeam->players[2].runsGiven<<"-"<<battingTeam->players[2].wicketsTaken<<" |"<<endl;
    cout<<"----------------------------------------"<<endl;
    cout<<"| ["<<"1"<<"]"<<battingTeam->players[3].name<<" \t"<<battingTeam->players[3].runsScored
    					<<"("<<battingTeam->players[3].ballsPlayed<<")"<<"\t\t "<<battingTeam->players[3].ballsBowled
    					<<"- "<<battingTeam->players[3].runsGiven<<"-"<<battingTeam->players[3].wicketsTaken<<" |"<<endl;
    cout<<"======================================="<<endl;
    cout<<endl;
    cout<<endl;

    cout<<bowlingTeam->name<<" "<<bowlingTeam->totalRunsScored<< " - "<<bowlingTeam->wicketsLost<<"("<<bowlingTeam->totalBallsBowled<<")"<<endl;
    cout<<"========================================"<<endl;
    cout<<"|PLAYER	      BATTING	       BOWLING|"<<endl;
   	cout<<"----------------------------------------"<<endl;
   	cout<<"| ["<<"0"<<"]"<<bowlingTeam->players[0].name<<"\t"<<bowlingTeam->players[0].runsScored
    				<<"("<<bowlingTeam->players[0].ballsPlayed<<")"<<"\t\t "<<battingTeam->players[0].ballsBowled
    				<<"- "<<battingTeam->players[0].runsGiven<<"-"<<bowlingTeam->players[0].wicketsTaken<<" |"<<endl;
    cout<<"----------------------------------------"<<endl;

    cout<<"| ["<<"1"<<"]"<<bowlingTeam->players[1].name<<" \t"<<bowlingTeam->players[1].runsScored
    					<<"("<<bowlingTeam->players[1].ballsPlayed<<")"<<"\t\t "<<bowlingTeam->players[1].ballsBowled
    					<<"- "<<bowlingTeam->players[1].runsGiven<<"-"<<bowlingTeam->players[1].wicketsTaken<<" |"<<endl;
   	cout<<"----------------------------------------"<<endl;
    cout<<"| ["<<"2"<<"]"<<bowlingTeam->players[2].name<<" \t"<<bowlingTeam->players[2].runsScored
    						<<"("<<bowlingTeam->players[2].ballsPlayed<<")"<<"\t\t "<<bowlingTeam->players[2].ballsBowled
    						<<"- "<<bowlingTeam->players[2].runsGiven<<"-"<<bowlingTeam->players[2].wicketsTaken<<" |"<<endl;
   	cout<<"----------------------------------------"<<endl;
   	cout<<"| ["<<"1"<<"]"<<bowlingTeam->players[3].name<<" \t"<<bowlingTeam->players[3].runsScored
    						<<"("<<bowlingTeam->players[3].ballsPlayed<<")"<<"\t\t "<<bowlingTeam->players[3].ballsBowled
    						<<"-"<<bowlingTeam->players[3].runsGiven<<"-"<<bowlingTeam->players[3].wicketsTaken<<" |"<<endl;

   	cout<<"========================================="<<endl;
}
